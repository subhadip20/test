package com.quick.siti.modal;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="route")
public class Routes {
	@Override
	public String toString() {
		return "Routes [id=" + id + ", source=" + source + ", destination=" + destination + ", routeDetails="
				+ routeDetails + ", busDetails=" + busDetails.toString() + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "SOURCE")
	private String source;
	
	@Column(name = "DESTINATION")
	private String destination;
	
	@Column(name = "ROUTE_DETAILS")
	private String routeDetails;
	@OneToMany
	(mappedBy = "route", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	
	 private Set<BusDetails> busDetails;
	
	
	
		public Set<BusDetails> getBusDetails() {
			return busDetails;
		}

		public void setBusDetails(Set<BusDetails> busDetails) {
			this.busDetails = busDetails;
		}
	
	
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getRouteDetails() {
		return routeDetails;
	}
	public void setRouteDetails(String routeDetails) {
		this.routeDetails = routeDetails;
	}
	public Routes() {
	
	}
	
	public Routes(String source, String destination, String routeDetails) {
		super();
		this.source = source;
		this.destination = destination;
		this.routeDetails = routeDetails;
	}

	
	
	
}
