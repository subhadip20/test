package com.quick.siti.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="busdetails")
public class BusDetails {
	
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "BUS_TYPE")
	private String busType;
	
	@Column(name = "FARE")
	private float fare;
	
	@Column(name = "ROUTE_TYPE")
	private String routeType;
	
	@Column(name = "JOURNEY_DATE")
	private String journeyDate;
	
	@Column(name = "DEPARTURE")
	private String departureTime;
	
	@Column(name = "ARRIVAL_TIME")
	private String arrivalTime;
	
	@Column(name = "IS_SEAT_AVL")
	private boolean isSeatAvl;
	
	@Column(name = "BOOKED_SEAT")
	private String bookedSeat;
	
	@Column(name = "ALL_AVL_SEAT")
	private String allSeat;

	
	 public Routes getRoute() {
		return route;
	}

	public void setRoute(Routes route) {
		this.route = route;
	}

	@ManyToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "bus_id")
	 private Bus bus;
	
	 @ManyToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "route_id")
	private Routes route;
	
	public Bus getBus() {
		return bus;
	}

	public void setBus(Bus bus) {
		this.bus = bus;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public float getFare() {
		return fare;
	}

	public void setFare(float fare) {
		this.fare = fare;
	}

	public String getRouteType() {
		return routeType;
	}

	public void setRouteType(String routeType) {
		this.routeType = routeType;
	}

	public String getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(String journeyDate) {
		this.journeyDate = journeyDate;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public boolean isSeatAvl() {
		return isSeatAvl;
	}

	public void setSeatAvl(boolean isSeatAvl) {
		this.isSeatAvl = isSeatAvl;
	}

	public String getBookedSeat() {
		return bookedSeat;
	}

	public void setBookedSeat(String bookedSeat) {
		this.bookedSeat = bookedSeat;
	}

	public String getAllSeat() {
		return allSeat;
	}

	public void setAllSeat(String allSeat) {
		this.allSeat = allSeat;
	}

	

	
	public BusDetails(String busType, float fare, String routeType, String journeyDate, String departureTime,
			String arrivalTime, boolean isSeatAvl, String bookedSeat, String allSeat, Bus bus, Routes route) {
		
		this.busType = busType;
		this.fare = fare;
		this.routeType = routeType;
		this.journeyDate = journeyDate;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.isSeatAvl = isSeatAvl;
		this.bookedSeat = bookedSeat;
		this.allSeat = allSeat;
		this.bus = bus;
		this.route = route;
	}

	public BusDetails() {
		
	}

	@Override
	public String toString() {
		return "BusDetails [id=" + id + ", busType=" + busType + ", fare=" + fare + ", routeType=" + routeType
				+ ", journeyDate=" + journeyDate + ", departureTime=" + departureTime + ", arrivalTime=" + arrivalTime
				+ ", isSeatAvl=" + isSeatAvl + ", bookedSeat=" + bookedSeat + ", allSeat=" + allSeat + ", bus=" + bus.toString()
				+ ", route=" + route.toString() + "]";
	}
	
	
	
	

}
