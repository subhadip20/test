package com.quick.siti.modal;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="reservation")
public class Reservation {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	@Column(name = "ALL_AVL_SEAT")
	private String allAvlSeat;
	@Column(name = "BOOKED_SEAT")
	private String bookedSeat;
	@Column(name = "IS_SEAT_AVL")
	private boolean isSeatAvl;
	@Column(name = "BOOKING_DATE")
	private String bookingDate;
	
	@ManyToOne(fetch = FetchType.EAGER)
	 @JoinColumn(name = "busdetails_id")
	private BusDetails busdetails;

	public int getId() {
		return id; 
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAllAvlSeat() {
		return allAvlSeat;
	}

	public void setAllAvlSeat(String allAvlSeat) {
		this.allAvlSeat = allAvlSeat;
	}

	public String getBookedSeat() {
		return bookedSeat;
	}

	public void setBookedSeat(String bookedSeat) {
		this.bookedSeat = bookedSeat;
	}

	public boolean isSeatAvl() {
		return isSeatAvl;
	}

	public void setSeatAvl(boolean isSeatAvl) {
		this.isSeatAvl = isSeatAvl;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public BusDetails getBusdetails() {
		return busdetails;
	}

	public void setBusdetails(BusDetails busdetails) {
		this.busdetails = busdetails;
	}

	public Reservation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Reservation(String allAvlSeat, String bookedSeat, boolean isSeatAvl, String bookingDate,
			BusDetails busdetails) {
		super();
		this.allAvlSeat = allAvlSeat;
		this.bookedSeat = bookedSeat;
		this.isSeatAvl = isSeatAvl;
		this.bookingDate = bookingDate;
		this.busdetails = busdetails;
	}

	@Override
	public String toString() {
		return "Reservation [id=" + id + ", allAvlSeat=" + allAvlSeat + ", bookedSeat=" + bookedSeat + ", isSeatAvl="
				+ isSeatAvl + ", bookingDate=" + bookingDate + ", busdetails=" + busdetails.toString() + "]";
	}
	
	
	
}
