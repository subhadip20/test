package com.quick.siti.jpaRepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.quick.siti.modal.BusDetails;


public interface BusDetailsRepository  extends JpaRepository<BusDetails, Integer>{

	@Query(value = "SELECT * FROM BUSDETAILS WHERE ROUTE_ID IN (SELECT ID FROM ROUTE WHERE SOURCE like ? AND DESTINATION  like ?)", nativeQuery = true)
	List<BusDetails> findAllBusByBusType(String source,String destination);
}