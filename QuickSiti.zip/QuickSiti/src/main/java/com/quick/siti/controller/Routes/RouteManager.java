package com.quick.siti.controller.Routes;
import java.net.InetAddress;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.net.ntp.NTPUDPClient;
import org.apache.commons.net.ntp.NtpV3Packet;
import org.apache.commons.net.ntp.TimeInfo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.quick.siti.jpaRepository.BusDetailsRepository;
import com.quick.siti.jpaRepository.BusRepository;
import com.quick.siti.jpaRepository.RouteRepository;
import com.quick.siti.modal.Bus;
import com.quick.siti.modal.BusDetails;
import com.quick.siti.modal.Routes;

@RestController
@RequestMapping("rest/admin")
public class RouteManager {
	
	@Autowired
	BusRepository busRepo;	
	@Autowired
	BusDetailsRepository busDetailRepo;
	
	@Autowired
	RouteRepository routeRepo;
	
	@GetMapping("/hello")
	public String welcome(){
		Calendar cal = Calendar.getInstance();
	    Date date=cal.getTime();
	    DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
	    String formattedDate=dateFormat.format(date);
	    System.out.println("Current time of the day using Calendar - 24 hour format: "+ formattedDate);
	    return formattedDate;
	}
	
	@GetMapping("/addbus")
	public String addBus(){
		
		Routes r = new Routes("HOWRAH", "ASANSOL", "HOWRAH-A-B-C-D-E-ASANSOL");
		r.setId(1);
		//routeRepo.save(r);
		Bus b = new Bus("WB12AJ6051", "EXTENDED", "MR. S DAS", "98989898989", "MR. K SING", "9898764534");
		//b.setId(1);
		busRepo.save(b);
		BusDetails bd = new BusDetails("AC", 310, "DOWN", "SUN-TUE-FRI", "8 PM", "1 AM", true, "21,23,", "21,23,24,25,27,30", b,r);
		busDetailRepo.save(bd);
		return "saved";
	}
	
	@GetMapping("/getAllBus/{source}/{destination}")
	public String getBus(@PathVariable(value = "source") String source,@PathVariable(value = "destination") String destination){
		List<BusDetails> b =busDetailRepo.findAllBusByBusType(source,destination);
		
	return b.toString();
	}
}
